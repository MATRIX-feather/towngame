# NiFeather Towngame

基本信息
=====================================
* 名称 : nifeather:towngame
* 版本 : generic,daily @ 11.3.0-20191017
* 游戏版本 : 1.14.4
* 测试版本 : 1.14.4
* 类型 : 原版模组

介绍
=====================================
* Towngame是一个PVP小游戏
* 尽可能多地收集资源,并确保自己在边界内,击败其他的玩家以获得胜利
* 请将资源包放置在第一位
* 详细介绍见源码页面中的wiki.md

源码
====================================
> [github](https://github.com/MATRIX-feather/towngame)

> [码云](https://gitee.com/matrix-feather/towngame)