# NiFeather Towngame

基本信息
=====================================
* 名称 : nifeather:towngame
* 版本 : generic,daily @ 11.3.0-20191017
* 游戏版本 : 1.14.4
* 测试版本 : 1.14.4
* 类型 : 原版模组

介绍
=====================================
* Towngame是一个PVP小游戏
* 尽可能多地收集资源,并确保自己在边界内,击败其他的玩家以获得胜利
* 请将资源包放置在第一位

下载/源码
====================================
> 度盘链接(停更) : [密码:vest](https://pan.baidu.com/s/1NuznUUlvsl7AmQfc3yIGBg)
> github : [github](https://github.com/MATRIX-feather/towngame)
> 码云(旧版) : [码云](https://gitee.com/matrix-feather/towngame)